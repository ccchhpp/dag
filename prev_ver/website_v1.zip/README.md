# dag

Carousel Dimensions: 4128x2322

Gallery Thumbnail Dimensions: 500x400